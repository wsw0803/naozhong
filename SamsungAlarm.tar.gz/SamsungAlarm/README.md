# SamsungAlarm（三星风格分组闹钟）

Kotlin + Jetpack Compose + Room 写的 Android 闹钟 App。

## 已实现的功能

- 分组页面：每个分组是一张卡片，卡片内是该组闹钟列表。
- 分组总开关：卡片右上角 Switch 一键开关整组闹钟。它只切换分组自身的启用状态，不会逐个改动组内闹钟的开关；单个闹钟是否真正响铃 = 自身开关 AND 分组开关。
- 复制闹钟：每条闹钟右侧的复制图标，点击即在同分组新建一个完全相同、默认关闭的副本。
- 新建 / 重命名 / 删除分组，新建 / 编辑 / 删除闹钟。
- 重复日选择（一~日）、标签、振动开关。
- 精确闹钟：AlarmManager.setExactAndAllowWhileIdle，到点发高优先级通知 + 振动。
- 开机 / 应用更新后自动重新注册所有闹钟。

## 目录结构

app/src/main/java/com/example/samsungalarm/
- AlarmApp.kt          Application，初始化 Room
- MainActivity.kt      入口，申请通知与精确闹钟权限
- alarm/AlarmScheduler.kt   写系统 AlarmManager
- alarm/AlarmReceiver.kt    到点响铃（通知 + 振动）
- alarm/BootReceiver.kt     开机恢复
- data/AlarmModels.kt       AlarmGroup / Alarm / 下次响铃计算
- data/AlarmDao.kt          Room DAO + Database
- data/AlarmRepository.kt   仓库，含 duplicateAlarm
- ui/AlarmViewModel.kt      分组+闹钟组合成 UI 状态
- ui/GroupScreen.kt         分组页面（核心界面）
- ui/AlarmEditDialog.kt     新建/编辑闹钟
- ui/theme/Theme.kt         配色，支持 Material You 动态取色

## 怎么编译

1. 用 Android Studio（Ladybug 或更新）打开 SamsungAlarm 目录；
2. 等 Gradle Sync 完成，首次会下载依赖；
3. 直接点 Run，或命令行 gradlew assembleDebug。

环境要求：JDK 17、Android SDK 34、Gradle 8.7（wrapper 已配置）。

## 首次运行注意

- 系统会请求通知权限和精确闹钟权限，都允许才会准点响；
- 部分国产 ROM 需给 App 加自启动 / 后台运行白名单，否则息屏后可能被清理。
